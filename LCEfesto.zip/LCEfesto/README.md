# LCEfesto
A sample project as part of our OOP course's finals.
